import { Zap, Sparkles, TrendingUp, Leaf, Brain, Coffee, Mail, Send } from 'lucide-react';
import { useState } from 'react';

function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="absolute top-0 w-full z-50 px-8 py-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Zap className="w-8 h-8 text-sky-300" />
            <span className="text-2xl font-bold bg-gradient-to-r from-sky-200 to-sky-400 bg-clip-text text-transparent">
              FocusFuel
            </span>
          </div>
          <button className="px-6 py-2 border border-sky-300/30 rounded-full hover:bg-sky-300/10 transition-all duration-300 text-sky-200">
            Sign In
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center">
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-sky-500/5 via-transparent to-sky-400/5"></div>

        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 -left-20 w-96 h-96 bg-sky-400/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-sky-300/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-8 py-20 grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-block">
              <span className="px-4 py-2 rounded-full bg-sky-400/10 border border-sky-300/20 text-sky-200 text-sm font-medium backdrop-blur-sm">
                Zero Sugar • Natural Caffeine • Focus Enhanced
              </span>
            </div>

            <h1 className="text-6xl lg:text-7xl font-bold leading-tight">
              Stay Focused,
              <br />
              <span className="bg-gradient-to-r from-sky-200 via-sky-300 to-sky-400 bg-clip-text text-transparent">
                Stay Fresh.
              </span>
            </h1>

            <p className="text-xl text-gray-400 leading-relaxed max-w-xl">
              Experience sustained energy without the crash. Our blend of natural caffeine and focus-enhancing ingredients keeps you performing at your peak.
            </p>

            {/* Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="flex items-center gap-3 bg-sky-400/5 rounded-lg p-4 border border-sky-300/10">
                <Zap className="w-5 h-5 text-sky-300" />
                <span className="text-sm font-medium text-sky-100">No Crash</span>
              </div>
              <div className="flex items-center gap-3 bg-sky-400/5 rounded-lg p-4 border border-sky-300/10">
                <Sparkles className="w-5 h-5 text-sky-300" />
                <span className="text-sm font-medium text-sky-100">100% Natural</span>
              </div>
              <div className="flex items-center gap-3 bg-sky-400/5 rounded-lg p-4 border border-sky-300/10">
                <TrendingUp className="w-5 h-5 text-sky-300" />
                <span className="text-sm font-medium text-sky-100">Peak Focus</span>
              </div>
            </div>

            {/* CTA */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button className="group relative px-8 py-4 bg-gradient-to-r from-sky-400 to-sky-500 rounded-full font-semibold text-black hover:shadow-lg hover:shadow-sky-400/50 transition-all duration-300 transform hover:scale-105">
                <span className="relative z-10">Get Your First Can Free</span>
                <div className="absolute inset-0 bg-gradient-to-r from-sky-300 to-sky-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
              <button className="px-8 py-4 border-2 border-sky-300/30 rounded-full font-semibold text-sky-200 hover:bg-sky-300/10 transition-all duration-300">
                Learn More
              </button>
            </div>

            {/* Social Proof */}
            <div className="flex items-center gap-6 pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-sky-300">50K+</div>
                <div className="text-sm text-gray-500">Students Trust Us</div>
              </div>
              <div className="h-12 w-px bg-sky-300/20"></div>
              <div className="text-center">
                <div className="text-3xl font-bold text-sky-300">4.9★</div>
                <div className="text-sm text-gray-500">Average Rating</div>
              </div>
            </div>
          </div>

          {/* Right Content - Product Image */}
          <div className="relative flex justify-center items-center">
            {/* Glow Effect Behind Image */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-96 h-96 bg-sky-400/20 rounded-full blur-3xl animate-pulse"></div>
            </div>

            {/* Product Image */}
            <div className="relative z-10 transform hover:scale-105 transition-transform duration-500">
              <img
                src="/ChatGPT Image Oct 17, 2025, 04_03_38 PM.png"
                alt="FocusFuel Energy Drink"
                className="w-full max-w-md drop-shadow-2xl"
              />
            </div>

            {/* Floating Elements */}
            <div className="absolute top-20 -left-10 bg-sky-400/10 backdrop-blur-md border border-sky-300/20 rounded-2xl p-4 animate-float">
              <div className="text-2xl font-bold text-sky-300">0g</div>
              <div className="text-xs text-gray-400">Sugar</div>
            </div>

            <div className="absolute bottom-32 -right-10 bg-sky-400/10 backdrop-blur-md border border-sky-300/20 rounded-2xl p-4 animate-float" style={{ animationDelay: '1s' }}>
              <div className="text-2xl font-bold text-sky-300">100%</div>
              <div className="text-xs text-gray-400">Natural</div>
            </div>
          </div>
        </div>
      </section>

      {/* Ingredients Section */}
      <section className="relative py-24 bg-black">
        {/* Background Effect */}
        <div className="absolute inset-0 bg-gradient-to-b from-sky-500/5 via-transparent to-transparent"></div>

        <div className="relative max-w-7xl mx-auto px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-sky-200 to-sky-400 bg-clip-text text-transparent">
                Power-Packed Ingredients
              </span>
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Every ingredient is carefully selected to enhance your focus and sustain your energy naturally.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Ingredient 1 */}
            <div className="group relative bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8 hover:border-sky-300/30 transition-all duration-300">
              <div className="absolute inset-0 bg-sky-400/0 group-hover:bg-sky-400/5 rounded-3xl transition-all duration-300"></div>
              <div className="relative">
                <div className="w-16 h-16 bg-sky-400/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Coffee className="w-8 h-8 text-sky-300" />
                </div>
                <h3 className="text-2xl font-bold text-sky-200 mb-3">Natural Caffeine</h3>
                <p className="text-gray-400 leading-relaxed mb-4">
                  120mg of clean caffeine from green tea extract provides sustained energy without the jitters or crash.
                </p>
                <div className="flex items-center gap-2 text-sky-300 text-sm font-medium">
                  <div className="w-2 h-2 bg-sky-300 rounded-full"></div>
                  120mg per serving
                </div>
              </div>
            </div>

            {/* Ingredient 2 */}
            <div className="group relative bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8 hover:border-sky-300/30 transition-all duration-300">
              <div className="absolute inset-0 bg-sky-400/0 group-hover:bg-sky-400/5 rounded-3xl transition-all duration-300"></div>
              <div className="relative">
                <div className="w-16 h-16 bg-sky-400/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Brain className="w-8 h-8 text-sky-300" />
                </div>
                <h3 className="text-2xl font-bold text-sky-200 mb-3">L-Theanine</h3>
                <p className="text-gray-400 leading-relaxed mb-4">
                  Promotes calm focus and mental clarity. Works synergistically with caffeine for optimal cognitive performance.
                </p>
                <div className="flex items-center gap-2 text-sky-300 text-sm font-medium">
                  <div className="w-2 h-2 bg-sky-300 rounded-full"></div>
                  200mg per serving
                </div>
              </div>
            </div>

            {/* Ingredient 3 */}
            <div className="group relative bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8 hover:border-sky-300/30 transition-all duration-300">
              <div className="absolute inset-0 bg-sky-400/0 group-hover:bg-sky-400/5 rounded-3xl transition-all duration-300"></div>
              <div className="relative">
                <div className="w-16 h-16 bg-sky-400/10 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Leaf className="w-8 h-8 text-sky-300" />
                </div>
                <h3 className="text-2xl font-bold text-sky-200 mb-3">B-Vitamins Complex</h3>
                <p className="text-gray-400 leading-relaxed mb-4">
                  Essential vitamins B6, B12, and niacin support energy metabolism and reduce mental fatigue.
                </p>
                <div className="flex items-center gap-2 text-sky-300 text-sm font-medium">
                  <div className="w-2 h-2 bg-sky-300 rounded-full"></div>
                  100% daily value
                </div>
              </div>
            </div>
          </div>

          {/* Additional Info */}
          <div className="mt-16 text-center">
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-sky-400/10 border border-sky-300/20 rounded-full">
              <Sparkles className="w-5 h-5 text-sky-300" />
              <span className="text-sky-200 font-medium">All ingredients are vegan, non-GMO, and lab-tested</span>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="relative py-24 bg-black">
        {/* Background Effect */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-sky-400/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold mb-4">
                <span className="bg-gradient-to-r from-sky-200 to-sky-400 bg-clip-text text-transparent">
                  Get in Touch
                </span>
              </h2>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Questions about FocusFuel? We're here to help you stay focused and energized.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div className="bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-sky-200 mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-black/50 border border-sky-300/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-sky-300/50 transition-colors"
                      placeholder="John Doe"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-sky-200 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-black/50 border border-sky-300/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-sky-300/50 transition-colors"
                      placeholder="john@university.edu"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-sky-200 mb-2">
                      Message
                    </label>
                    <textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={4}
                      className="w-full px-4 py-3 bg-black/50 border border-sky-300/20 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-sky-300/50 transition-colors resize-none"
                      placeholder="Tell us how we can help..."
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full px-8 py-4 bg-gradient-to-r from-sky-400 to-sky-500 rounded-xl font-semibold text-black hover:shadow-lg hover:shadow-sky-400/50 transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Send Message
                  </button>
                </form>
              </div>

              {/* Contact Info */}
              <div className="space-y-8">
                <div className="bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-sky-400/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-sky-300" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-sky-200 mb-2">Email Us</h3>
                      <p className="text-gray-400 mb-3">Get a response within 24 hours</p>
                      <a href="mailto:hello@focusfuel.com" className="text-sky-300 hover:text-sky-200 transition-colors">
                        hello@focusfuel.com
                      </a>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-sky-400/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Zap className="w-6 h-6 text-sky-300" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-sky-200 mb-2">Student Support</h3>
                      <p className="text-gray-400 mb-3">Special discounts and bulk orders</p>
                      <a href="mailto:students@focusfuel.com" className="text-sky-300 hover:text-sky-200 transition-colors">
                        students@focusfuel.com
                      </a>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-sky-400/5 to-transparent border border-sky-300/10 rounded-3xl p-8">
                  <h3 className="text-xl font-bold text-sky-200 mb-4">Follow Us</h3>
                  <div className="flex gap-4">
                    <button className="w-12 h-12 bg-sky-400/10 hover:bg-sky-400/20 rounded-xl flex items-center justify-center transition-colors">
                      <span className="text-sky-300 font-bold">IG</span>
                    </button>
                    <button className="w-12 h-12 bg-sky-400/10 hover:bg-sky-400/20 rounded-xl flex items-center justify-center transition-colors">
                      <span className="text-sky-300 font-bold">TW</span>
                    </button>
                    <button className="w-12 h-12 bg-sky-400/10 hover:bg-sky-400/20 rounded-xl flex items-center justify-center transition-colors">
                      <span className="text-sky-300 font-bold">FB</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative border-t border-sky-300/10 py-8">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Zap className="w-6 h-6 text-sky-300" />
              <span className="text-lg font-bold bg-gradient-to-r from-sky-200 to-sky-400 bg-clip-text text-transparent">
                FocusFuel
              </span>
            </div>
            <p className="text-gray-500 text-sm">
              © 2025 FocusFuel. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
